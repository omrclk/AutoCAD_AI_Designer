# AutoCAD AI Designer V4 — AutoCAD 2022

AutoCAD içinde dockable bir sohbet paneli: doğal dille istek yazarsınız, yapay zekâ **öneri planı** üretir, plan çizimde **renkli hayalet önizleme** olarak görünür, siz onaylarsınız, değişiklik **tek adımda** uygulanır ve **tek UNDO ile geri alınır**.

> **Önemli (dürüst not):** Kod bu ortamda gerçek AutoCAD 2022 DLL'leriyle derlenemedi. Doğrulananlar: Python servisi (19 birim test), C# kodunun söz dizimi/tür kontrolü (AutoCAD API'si taklit edilerek) ve doğrulama mantığı (mono üzerinde çalıştırıldı). AutoCAD'e özgü davranış (panel, seçim, önizleme, işlem) **sizin makinenizde ilk kez çalışacak**. İlk denemeyi bir DWG **kopyasında** yapın.

## V3'e göre neler değişti
| Alan | V3 | V4 |
|---|---|---|
| Kurulum | 2 terminal, token ortam değişkeni, her seferinde NETLOAD | `install.ps1` tek komut; AutoCAD açılınca otomatik yüklenir |
| Servis | Elle başlatılıyordu | Eklenti gizli başlatır, rastgele port+token, AutoCAD kapanınca kendini kapatır |
| API anahtarı | Ortam değişkeni | Panelden girilir, Windows DPAPI ile şifreli saklanır |
| Seçim | `SelectImplied` (panel odaktayken güvenilmez) | `Nesne seç` düğmesi → gerçek AutoCAD komutu |
| Uygulama | Modeless koddan yazma | Gerçek komut içinde tek transaction → **tek UNDO**, hata olursa çizim değişmez |
| Önizleme | Sadece metin | Transient grafik hayaleti + Türkçe işlem özeti |
| İşlemler | taşı, katman, çizgi, daire | + kopyala, döndür, ölçekle, katman oluştur, polyline, dikdörtgen, yazı, blok ekle |
| Konuşma | Her istek bağımsız | Çok turlu sohbet belleği |
| Model hatası | Düz hata | Geçersiz plan otomatik bir kez düzeltilir; anlaşılır Türkçe hata (kota, anahtar, model) |
| Yedek | DWG'nin yanına çöp dosya | `%LOCALAPPDATA%\CadAiDesigner\backups` (son 30) |
| Düzeltilen hatalar | bkz. `DEGISIKLIKLER.md` | |

## Gereksinimler
Windows 10/11 · AutoCAD **2022** · Visual Studio 2022 **Build Tools** (".NET masaüstü derleme araçları" + ".NET Framework 4.8 hedefleme paketi") · Python **3.9+** (PATH'te) · OpenAI **API** anahtarı ve kredisi (ChatGPT Plus API'yi kapsamaz).

## Kurulum
1. Zip'i bir klasöre çıkarın (ör. `C:\AI-Agent-V4`).
2. AutoCAD'i kapatın. PowerShell'de:
   ```powershell
   cd C:\AI-Agent-V4
   powershell -ExecutionPolicy Bypass -File .\install.ps1
   ```
   (AutoCAD farklı yerdeyse: `-AutoCADDir 'D:\Autodesk\AutoCAD 2022'`.) Betik testleri çalıştırır, derler ve `%APPDATA%\Autodesk\ApplicationPlugins\CadAiDesigner.bundle` altına kurar.
3. AutoCAD'i açın → `AIDESIGNER` → panelde **Ayarlar** → API anahtarını girin → Kaydet.

Kaldırma: `.\uninstall.ps1` (ayarları da silmek için `-RemoveData`).

## Kullanım
1. Bir DWG **kopyası** açın, kaydedin.
2. Nesneleri seçin → panelde **Nesne seç**.
3. İsteği yazın, **Ctrl+Enter**: ör. *"Seçilenleri X yönünde 500 birim kopyala"*, *"Seçili nesneleri DUVAR katmanına al, katman yoksa kırmızı oluştur"*, *"Seçilenleri sol kenara hizala"*, *"0,0 köşeli 4000×3000 dikdörtgen çiz"*.
4. Önizlemeyi AutoCAD'de inceleyin (yeşil: değişen, sarı: kopya, camgöbeği: yeni) → **Onayla / Uygula**.
5. Beğenmezseniz `Ctrl+Z` (tek adımda geri alır). Kaydetmek sizde.

`AIDSELECT` ve `AIDAPPLY` panelin iç komutlarıdır, elle çalıştırmayın.

## Güvenlik ve gizlilik
- Yalnızca izin listesindeki 12 işlem çalışır; silme, komut/script çalıştırma yoktur. Her plan hem Python'da hem C#'ta (yetkili) doğrulanır; seçili olmayan nesneye dokunulamaz; kilitli/dondurulmuş katman reddedilir.
- Servis yalnızca `127.0.0.1`'de dinler, oturuma özel rastgele token ister, proxy'yi atlar.
- **Seçili nesnelerin bilgisi (tür, katman, ölçü, metin içeriği) OpenAI'a gönderilir.** Gizli/kısıtlı çizimlerde kurumsal onay olmadan kullanmayın.
- Günlükler: `%LOCALAPPDATA%\CadAiDesigner\logs` (istek metni ve uygulanan plan özeti; anahtar ve geometri yazılmaz).

## Sorun giderme
| Belirti | Çözüm |
|---|---|
| `AIDESIGNER` tanınmıyor | Kurulum sonrası AutoCAD'i yeniden açın; `SECURELOAD`/güven uyarısı çıkarsa "Always load" deyin |
| "Python 3.9+ bulunamadı" | python.org'dan kurun (Add to PATH) veya Ayarlar'da `python.exe` yolunu girin. Microsoft Store'un sahte `python` kısayolu sayılmaz |
| "Servis başlamadı" | Mesajdaki son satırlar nedeni gösterir; `%LOCALAPPDATA%\CadAiDesigner\logs\service.log` |
| Kota/401/404 hatası | Mesaj Türkçe açıklar: kredi, anahtar veya model adı |
| Önizleme görünmüyor | Planı iptal edip yeniden hazırlayın (`REGEN`); uygulama önizlemesiz de çalışır |
| Derleme hatası `error CS...` | Satırı bana iletin; AutoCAD API'sine özgü bir uyumsuzluk olabilir |

Elle hata ayıklama: `scripts\dev-service.ps1 -LaunchAutoCAD`.

## Bilinen sınırlar
- Önizleme her işlemi **orijinal geometriden** gösterir (aynı nesneye zincirleme işlem varsa yaklaşıktır); uygulama doğru sırayla yapılır.
- Kopyalama `DeepClone` kullanır; dinamik blok parametreleri, xref içeriği ve annotative ayarlar özel olarak ele alınmaz.
- Koordinatlar her zaman WCS ve çizim birimindedir; UCS döndürülmüşse model yine WCS'e göre hesaplar.
- Seçim en fazla 100 nesne gönderir; çok büyük seçimlerde sonuç kalitesi düşer.
- Yedek yalnızca son **kaydedilmiş** DWG'dir; kaydedilmemiş iş için UNDO kullanın.
- Model geometriyi yanlış hesaplayabilir; önizlemeyi her zaman kontrol edin.

## Ticari ürün yolunda (kod dışı işler)
Kod imzalama (Authenticode), MSI/Inno Setup kurulum paketi (Python'u PyInstaller ile tek `.exe` yapıp bağımsız kurulum), lisanslama/aktivasyon, çoklu AutoCAD sürümü testi (2023-2025 için .NET 8 geçişi), otomatik güncelleme, kullanım koşulları/gizlilik politikası, kendi backend'iniz üzerinden API anahtarı yönetimi ve Autodesk App Store yayın süreci.
