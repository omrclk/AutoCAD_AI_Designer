import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'service'))
from actions import validate_actions, PlanError


def ctx():
    return {
        'selected': [{'handle': 'A1'}, {'handle': '2b'}],
        'layers': [{'name': '0'}, {'name': 'Duvar'}],
        'blocks': ['Priz'],
    }


class ActionTests(unittest.TestCase):
    def ok(self, a):
        return validate_actions([a], ctx())[0]

    def bad(self, a):
        with self.assertRaises(PlanError):
            validate_actions([a], ctx())

    def test_move_normalizes(self):
        n = self.ok({'type': 'move', 'handles': ['a1', '0x2B'], 'dx': 5})
        self.assertEqual(n['handles'], ['A1', '2B'])
        self.assertEqual((n['dx'], n['dy'], n['dz']), (5.0, 0.0, 0.0))

    def test_unselected_handle_rejected(self):
        self.bad({'type': 'move', 'handles': ['FF'], 'dx': 1})

    def test_zero_move_rejected(self):
        self.bad({'type': 'move', 'handles': ['A1']})

    def test_delete_rejected(self):
        self.bad({'type': 'erase', 'handles': ['A1']})

    def test_layer_must_exist_or_be_created(self):
        self.bad({'type': 'circle', 'center': [0, 0], 'radius': 1, 'layer': 'Yok'})
        r = validate_actions([
            {'type': 'create_layer', 'name': 'Yeni', 'color_index': 3},
            {'type': 'circle', 'center': [0, 0], 'radius': 1, 'layer': 'yeni'}], ctx())
        self.assertEqual(len(r), 2)

    def test_bad_layer_name(self):
        self.bad({'type': 'create_layer', 'name': 'a<b'})

    def test_nan_and_bool_rejected(self):
        self.bad({'type': 'circle', 'center': [0, 0], 'radius': float('nan')})
        self.bad({'type': 'circle', 'center': [True, 0], 'radius': 1})

    def test_polyline_rectangle_text_block(self):
        self.ok({'type': 'polyline', 'points': [[0, 0], [1, 1]], 'closed': True})
        self.bad({'type': 'polyline', 'points': [[0, 0]]})
        self.ok({'type': 'rectangle', 'corner1': [0, 0], 'corner2': [2, 3]})
        self.bad({'type': 'rectangle', 'corner1': [0, 0], 'corner2': [0, 3]})
        self.ok({'type': 'text', 'position': [0, 0], 'text': 'Merhaba', 'height': 2.5})
        self.ok({'type': 'insert_block', 'name': 'priz', 'position': [1, 1]})
        self.bad({'type': 'insert_block', 'name': 'Bilinmeyen', 'position': [1, 1]})

    def test_scale_range(self):
        self.bad({'type': 'scale', 'handles': ['A1'], 'factor': 0, 'base': [0, 0]})
        self.ok({'type': 'scale', 'handles': ['A1'], 'factor': 2, 'base': [0, 0]})

    def test_too_many(self):
        a = {'type': 'line', 'start': [0, 0], 'end': [1, 1]}
        with self.assertRaises(PlanError):
            validate_actions([a] * 31, ctx())


if __name__ == '__main__':
    unittest.main()
