using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;

namespace CadAiDesigner
{
    internal static class ContextBuilder
    {
        const int MaxSelected = 100;

        static double R(double v) { return Math.Round(v, 4); }
        static double[] P(Point3d p) { return new[] { R(p.X), R(p.Y), R(p.Z) }; }
        static string Trunc(string s, int n) { return s == null ? "" : (s.Length <= n ? s : s.Substring(0, n)); }

        public static DrawingContext Build(Document doc, IList<ObjectId> ids)
        {
            Database db = doc.Database;
            DrawingContext ctx = new DrawingContext();
            ctx.DrawingName = doc.Name;
            ctx.Units = db.Insunits.ToString() + (db.Insunits == UnitsValue.Undefined ? " (birim tanımsız)" : "");
            ctx.Space = db.TileMode ? "Model" : "Paper";
            StringBuilder fp = new StringBuilder(doc.Name);

            using (Transaction tx = db.TransactionManager.StartTransaction())
            {
                LayerTable lt = (LayerTable)tx.GetObject(db.LayerTableId, OpenMode.ForRead);
                foreach (ObjectId lid in lt)
                {
                    LayerTableRecord l = (LayerTableRecord)tx.GetObject(lid, OpenMode.ForRead);
                    if (l.IsErased) continue;
                    ctx.Layers.Add(new LayerInfo { Name = l.Name, Frozen = l.IsFrozen, Locked = l.IsLocked, Off = l.IsOff });
                }
                LayerTableRecord cur = (LayerTableRecord)tx.GetObject(db.Clayer, OpenMode.ForRead);
                ctx.CurrentLayer = cur.Name;

                BlockTable bt = (BlockTable)tx.GetObject(db.BlockTableId, OpenMode.ForRead);
                foreach (ObjectId bid in bt)
                {
                    BlockTableRecord b = (BlockTableRecord)tx.GetObject(bid, OpenMode.ForRead);
                    if (b.IsErased || b.IsAnonymous || b.IsLayout || b.IsFromExternalReference || b.IsDependent || b.Name.StartsWith("*")) continue;
                    ctx.Blocks.Add(b.Name);
                }

                List<ObjectId> alive = ids.Where(i => !i.IsErased).ToList();
                ctx.SelectionTotal = alive.Count;
                List<Entity> ents = new List<Entity>();
                foreach (ObjectId id in alive)
                {
                    Entity ent = tx.GetObject(id, OpenMode.ForRead) as Entity;
                    if (ent != null) ents.Add(ent);
                }
                foreach (Entity ent in ents.OrderBy(e => e.Handle.ToString(), StringComparer.OrdinalIgnoreCase).Take(MaxSelected))
                {
                    Dictionary<string, object> item = Describe(tx, ent);
                    ctx.Selected.Add(item);
                    string h = (string)item["handle"];
                    ctx.HandleSet.Add(h);
                    object ext;
                    fp.Append('|').Append(h).Append(',').Append(ent.Layer).Append(',');
                    if (item.TryGetValue("extents", out ext)) fp.Append(string.Join(",", ((double[])ext).Select(x => x.ToString("R", System.Globalization.CultureInfo.InvariantCulture))));
                }
                tx.Commit();
            }
            using (SHA1 sha = SHA1.Create())
                ctx.Fingerprint = BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(fp.ToString()))).Replace("-", "");
            return ctx;
        }

        static Dictionary<string, object> Describe(Transaction tx, Entity ent)
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["handle"] = ent.Handle.ToString().ToUpperInvariant();
            d["type"] = ent.GetType().Name;
            d["layer"] = ent.Layer;
            try
            {
                Extents3d e = ent.GeometricExtents;
                d["extents"] = new[] { R(e.MinPoint.X), R(e.MinPoint.Y), R(e.MaxPoint.X), R(e.MaxPoint.Y) };
            }
            catch (System.Exception) { }

            Line ln = ent as Line;
            Circle ci = ent as Circle;
            Arc arc = ent as Arc;
            Polyline pl = ent as Polyline;
            BlockReference br = ent as BlockReference;
            DBText tx1 = ent as DBText;
            MText mt = ent as MText;

            if (ln != null) { d["start"] = P(ln.StartPoint); d["end"] = P(ln.EndPoint); d["length"] = R(ln.Length); }
            else if (arc != null) { d["center"] = P(arc.Center); d["radius"] = R(arc.Radius); d["start_angle_deg"] = R(arc.StartAngle * 180.0 / Math.PI); d["end_angle_deg"] = R(arc.EndAngle * 180.0 / Math.PI); }
            else if (ci != null) { d["center"] = P(ci.Center); d["radius"] = R(ci.Radius); }
            else if (pl != null)
            {
                d["closed"] = pl.Closed;
                d["vertex_count"] = pl.NumberOfVertices;
                List<double[]> vs = new List<double[]>();
                for (int i = 0; i < pl.NumberOfVertices && i < 30; i++) { Point2d p = pl.GetPoint2dAt(i); vs.Add(new[] { R(p.X), R(p.Y) }); }
                d["vertices"] = vs;
                try { d["length"] = R(pl.Length); } catch (System.Exception) { }
            }
            else if (br != null)
            {
                string name = br.Name;
                try
                {
                    if (br.IsDynamicBlock)
                        name = ((BlockTableRecord)tx.GetObject(br.DynamicBlockTableRecord, OpenMode.ForRead)).Name;
                }
                catch (System.Exception) { }
                d["block_name"] = name;
                d["position"] = P(br.Position);
                d["rotation_deg"] = R(br.Rotation * 180.0 / Math.PI);
                d["scale"] = new[] { R(br.ScaleFactors.X), R(br.ScaleFactors.Y), R(br.ScaleFactors.Z) };
            }
            else if (tx1 != null) { d["text"] = Trunc(tx1.TextString, 120); d["height"] = R(tx1.Height); d["position"] = P(tx1.Position); }
            else if (mt != null) { d["text"] = Trunc(mt.Contents, 120); d["height"] = R(mt.TextHeight); d["position"] = P(mt.Location); }
            else
            {
                Curve c = ent as Curve;
                if (c != null)
                {
                    try { d["length"] = R(c.GetDistanceAtParameter(c.EndParam) - c.GetDistanceAtParameter(c.StartParam)); }
                    catch (System.Exception) { }
                }
            }
            return d;
        }
    }
}
