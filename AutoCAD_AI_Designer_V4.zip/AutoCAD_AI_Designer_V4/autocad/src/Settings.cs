using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace CadAiDesigner
{
    internal static class AppPaths
    {
        public static string Dir
        {
            get
            {
                string d = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CadAiDesigner");
                Directory.CreateDirectory(d);
                return d;
            }
        }
        public static string Logs { get { string d = Path.Combine(Dir, "logs"); Directory.CreateDirectory(d); return d; } }
        public static string Backups { get { string d = Path.Combine(Dir, "backups"); Directory.CreateDirectory(d); return d; } }
    }

    /// <summary>Append-only audit log (prompts and applied plans; never the API key or drawing geometry).</summary>
    internal static class AppLog
    {
        static readonly object Gate = new object();
        public static void Write(string line)
        {
            try
            {
                lock (Gate)
                    File.AppendAllText(Path.Combine(AppPaths.Logs, DateTime.Now.ToString("yyyyMMdd") + ".log"),
                        DateTime.Now.ToString("HH:mm:ss") + " " + line + Environment.NewLine, Encoding.UTF8);
            }
            catch (System.Exception) { }
        }
    }

    /// <summary>User settings. The API key is stored encrypted with Windows DPAPI (current user only).</summary>
    internal class Settings
    {
        public string Model = "gpt-4.1-mini";
        public string PythonPath = "";
        public string ApiKeyProtected = "";
        public bool BackupBeforeApply = true;

        static readonly byte[] Entropy = Encoding.UTF8.GetBytes("CadAiDesigner.v4");
        static string FilePath { get { return Path.Combine(AppPaths.Dir, "settings.json"); } }

        public static Settings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    Settings s = new JavaScriptSerializer().Deserialize<Settings>(File.ReadAllText(FilePath, Encoding.UTF8));
                    if (s != null) return s;
                }
            }
            catch (System.Exception) { }
            return new Settings();
        }

        public void Save()
        {
            File.WriteAllText(FilePath, new JavaScriptSerializer().Serialize(this), Encoding.UTF8);
        }

        public bool HasStoredKey { get { return !string.IsNullOrEmpty(ApiKeyProtected); } }

        public void SetApiKey(string key)
        {
            ApiKeyProtected = string.IsNullOrWhiteSpace(key) ? "" :
                Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(key.Trim()), Entropy, DataProtectionScope.CurrentUser));
        }

        /// <summary>Stored key, or the OPENAI_API_KEY environment variable as fallback.</summary>
        public string GetApiKey()
        {
            if (HasStoredKey)
            {
                try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(ApiKeyProtected), Entropy, DataProtectionScope.CurrentUser)); }
                catch (System.Exception) { }
            }
            return Environment.GetEnvironmentVariable("OPENAI_API_KEY") ?? "";
        }
    }

    internal class SettingsForm : Form
    {
        readonly TextBox key = new TextBox { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
        readonly TextBox model = new TextBox { Dock = DockStyle.Fill };
        readonly TextBox python = new TextBox { Dock = DockStyle.Fill };
        readonly CheckBox backup = new CheckBox { Text = "Uygulamadan önce kayıtlı DWG'nin yedeğini al", AutoSize = true };
        readonly Settings settings;

        public SettingsForm(Settings s)
        {
            settings = s;
            Text = "AutoCAD AI Designer — Ayarlar";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(480, 250);

            model.Text = s.Model;
            python.Text = s.PythonPath;
            backup.Checked = s.BackupBeforeApply;
            if (s.HasStoredKey) key.Text = "";

            TableLayoutPanel t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Padding = new Padding(12) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            AddRow(t, "OpenAI API anahtarı", key);
            Label hint = new Label { AutoSize = true, ForeColor = SystemColors.GrayText,
                Text = s.HasStoredKey ? "Kayıtlı bir anahtar var. Değiştirmek için yenisini yazın; boş bırakırsanız korunur."
                                      : "Anahtar yalnızca bu Windows kullanıcısı için şifreli saklanır (DPAPI)." };
            t.Controls.Add(new Label()); t.Controls.Add(hint);
            AddRow(t, "Model", model);
            AddRow(t, "Python yolu (ops.)", python);
            t.Controls.Add(new Label()); t.Controls.Add(backup);

            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, FlowDirection = FlowDirection.RightToLeft, Height = 44, Padding = new Padding(8) };
            Button ok = new Button { Text = "Kaydet", DialogResult = DialogResult.OK };
            Button cancel = new Button { Text = "Vazgeç", DialogResult = DialogResult.Cancel };
            buttons.Controls.Add(cancel); buttons.Controls.Add(ok);
            Controls.Add(t); Controls.Add(buttons);
            AcceptButton = ok; CancelButton = cancel;
            ok.Click += (o, e) => Commit();
        }

        static void AddRow(TableLayoutPanel t, string label, Control c)
        {
            t.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 6, 0, 0) });
            t.Controls.Add(c);
        }

        void Commit()
        {
            if (key.Text.Trim().Length > 0) settings.SetApiKey(key.Text);
            settings.Model = string.IsNullOrWhiteSpace(model.Text) ? "gpt-4.1-mini" : model.Text.Trim();
            settings.PythonPath = python.Text.Trim();
            settings.BackupBeforeApply = backup.Checked;
            settings.Save();
        }
    }
}
