using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace CadAiDesigner
{
    public class DesignerPanel : UserControl
    {
        readonly TextBox chat = new TextBox();
        readonly TextBox prompt = new TextBox();
        readonly Label status = new Label();
        readonly Button btnSelect = new Button(), btnAsk = new Button(), btnApply = new Button(),
                        btnCancel = new Button(), btnNew = new Button(), btnSettings = new Button();
        readonly JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 8000000, RecursionLimit = 40 };
        string session = Guid.NewGuid().ToString("N");
        bool busy;

        public DesignerPanel()
        {
            Dock = DockStyle.Fill;
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(8) };
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 74));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            status.Dock = DockStyle.Fill; status.AutoSize = true; status.Padding = new Padding(0, 0, 0, 6);
            chat.Multiline = true; chat.ReadOnly = true; chat.ScrollBars = ScrollBars.Vertical; chat.Dock = DockStyle.Fill;
            chat.Font = new Font("Segoe UI", 9); chat.BackColor = SystemColors.Window;
            prompt.Multiline = true; prompt.ScrollBars = ScrollBars.Vertical; prompt.Dock = DockStyle.Fill; prompt.Font = new Font("Segoe UI", 9.5f);
            prompt.KeyDown += (s, e) =>
            {
                if (e.Control && e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AskAsync().ContinueWith(t => { }); }
            };

            Setup(btnSelect, "Nesne seç", (s, e) => SelectObjects());
            Setup(btnAsk, "Plan hazırla", async (s, e) => await AskAsync());
            Setup(btnApply, "Onayla / Uygula", (s, e) => ApplyClicked());
            Setup(btnCancel, "İptal", (s, e) => { ClearPlan(); Log("Plan iptal edildi."); });
            Setup(btnNew, "Yeni sohbet", (s, e) => NewChat());
            Setup(btnSettings, "Ayarlar", (s, e) => OpenSettings());
            btnApply.Enabled = false; btnCancel.Enabled = false;

            FlowLayoutPanel buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
            buttons.Controls.AddRange(new Control[] { btnSelect, btnAsk, btnApply, btnCancel, btnNew, btnSettings });
            Label tip = new Label
            {
                Dock = DockStyle.Fill, AutoSize = true, ForeColor = SystemColors.GrayText, Padding = new Padding(0, 6, 0, 0),
                Text = "Ctrl+Enter: gönder. Önizleme AutoCAD'de renkli hayalet olarak görünür (yeşil: taşınan/değişen, sarı: kopya, camgöbeği: yeni). Uygulama tek UNDO ile geri alınır. Ölçüler çizim birimindedir."
            };
            layout.Controls.Add(status, 0, 0);
            layout.Controls.Add(chat, 0, 1);
            layout.Controls.Add(prompt, 0, 2);
            layout.Controls.Add(buttons, 0, 3);
            layout.Controls.Add(tip, 0, 4);
            Controls.Add(layout);

            SelectionState.Changed += OnSelectionChanged;
            Commands.ApplyFinished += OnApplyFinished;
            AcadApp.DocumentManager.DocumentActivated += OnDocumentActivated;
            RefreshStatus();
            Log("Hazır. Çizimde nesne seçip 'Nesne seç'e basın (seçim olmadan yalnızca yeni nesne çizilebilir), sonra isteğinizi yazın.");
        }

        static void Setup(Button b, string text, EventHandler click)
        {
            b.Text = text; b.AutoSize = true; b.Padding = new Padding(4, 0, 4, 0); b.Click += click;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                SelectionState.Changed -= OnSelectionChanged;
                Commands.ApplyFinished -= OnApplyFinished;
                try { AcadApp.DocumentManager.DocumentActivated -= OnDocumentActivated; } catch (System.Exception) { }
            }
            base.Dispose(disposing);
        }

        void Log(string s) { chat.AppendText(s + Environment.NewLine + Environment.NewLine); }

        void RefreshStatus()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            int n = doc == null ? 0 : SelectionState.For(doc).Count;
            status.Text = "Seçili nesne: " + n + "   |   Servis: " + (ServiceHost.IsRunning ? "çalışıyor" : "beklemede");
        }

        void ClearPlan()
        {
            PlanState.Current = null;
            Preview.Clear();
            btnApply.Enabled = false; btnCancel.Enabled = false;
        }

        void OnSelectionChanged()
        {
            if (PlanState.Current != null) { ClearPlan(); Log("Seçim değişti; bekleyen plan iptal edildi."); }
            RefreshStatus();
        }

        void OnDocumentActivated(object sender, DocumentCollectionEventArgs e)
        {
            if (PlanState.Current != null) { ClearPlan(); Log("Çizim değişti; bekleyen plan iptal edildi."); }
            RefreshStatus();
        }

        void OnApplyFinished(bool ok, string message)
        {
            ClearPlan();
            Log(message);
            RefreshStatus();
        }

        void SelectObjects()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (doc == null) { Log("Açık DWG yok."); return; }
            if (!doc.Editor.IsQuiescent) { Log("AutoCAD'de çalışan bir komut var; Esc ile bitirip tekrar deneyin."); return; }
            doc.SendStringToExecute("AIDSELECT ", true, false, false);
            AcadApp.MainWindow.Focus(); // so AutoCAD receives the selection clicks
        }

        void NewChat()
        {
            session = Guid.NewGuid().ToString("N");
            chat.Clear();
            ClearPlan();
            Log("Yeni sohbet başlatıldı.");
        }

        void OpenSettings()
        {
            Settings s = Settings.Load();
            using (SettingsForm f = new SettingsForm(s))
            {
                if (AcadApp.ShowModalDialog(f) == DialogResult.OK)
                {
                    ServiceHost.Stop(); // restarted with the new key/model on the next request
                    Log("Ayarlar kaydedildi.");
                    RefreshStatus();
                }
            }
        }

        void SetBusy(bool value)
        {
            busy = value;
            btnAsk.Enabled = !value;
            if (value) { btnApply.Enabled = false; status.Text = "Plan hazırlanıyor..."; }
            else RefreshStatus();
        }

        async Task AskAsync()
        {
            if (busy) return;
            string msg = prompt.Text.Trim();
            if (msg.Length == 0) return;
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (doc == null) { Log("Açık DWG yok."); return; }

            SetBusy(true);
            try
            {
                ClearPlan();
                Log("Siz: " + msg);
                DrawingContext ctx = ContextBuilder.Build(doc, SelectionState.For(doc));
                Settings s = Settings.Load();
                string json = js.Serialize(new Dictionary<string, object> { { "message", msg }, { "session", session }, { "context", ctx.ToJson() } });
                AppLog.Write("ASK [" + System.IO.Path.GetFileName(doc.Name) + ", sel=" + ctx.SelectionTotal + "] " + msg);

                string body = await Task.Run(() => { ServiceHost.EnsureStarted(s); return ServiceHost.Post("/plan", json); });
                Dictionary<string, object> resp = js.Deserialize<Dictionary<string, object>>(body);
                if (resp == null) throw new InvalidOperationException("Servisten boş yanıt geldi.");
                if (resp.ContainsKey("error")) throw new InvalidOperationException(Convert.ToString(resp["error"]));

                Log("AI: " + J.Str(resp, "reply"));
                List<Dictionary<string, object>> actions = new List<Dictionary<string, object>>();
                List<object> list = J.Arr(J.Get(resp, "actions"));
                if (list != null) foreach (object o in list) { Dictionary<string, object> d = o as Dictionary<string, object>; if (d != null) actions.Add(d); }

                if (actions.Count > 0)
                {
                    try { PlanValidator.Validate(actions, ctx); }
                    catch (InvalidOperationException ex) { Log("Güvenlik doğrulaması planı reddetti: " + ex.Message); return; }
                    PlanState.Current = new PendingPlan { Doc = doc, Actions = actions, Fingerprint = ctx.Fingerprint, Prompt = msg };
                    int i = 1;
                    foreach (Dictionary<string, object> a in actions) Log("  " + (i++) + ") " + PlanDescriber.Describe(a));
                    Preview.Show(doc, actions);
                    btnApply.Enabled = true; btnCancel.Enabled = true;
                    Log("Bu bir ÖNERİDİR; çizime henüz hiçbir şey yazılmadı. Uygun ise 'Onayla / Uygula'.");
                }
                prompt.Clear();
            }
            catch (System.Exception ex)
            {
                ClearPlan();
                Log("Hata: " + ex.Message);
            }
            finally { SetBusy(false); }
        }

        void ApplyClicked()
        {
            PendingPlan plan = PlanState.Current;
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (plan == null || doc == null) return;
            if (plan.Doc != doc) { ClearPlan(); Log("Çizim değişti; planı yeniden hazırlayın."); return; }
            if (!doc.Editor.IsQuiescent) { Log("AutoCAD'de çalışan bir komut var; Esc ile bitirip tekrar deneyin."); return; }

            string text = plan.Actions.Count + " işlem '" + System.IO.Path.GetFileName(doc.Name) + "' çizimine uygulanacak:\n\n" +
                string.Join("\n", plan.Actions.Take(12).Select((a, i) => (i + 1) + ") " + PlanDescriber.Describe(a))) +
                (plan.Actions.Count > 12 ? "\n..." : "") +
                "\n\nTek adımda uygulanır; UNDO ile geri alınabilir. Devam edilsin mi?";
            if (MessageBox.Show(text, "AutoCAD AI Designer", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            btnApply.Enabled = false;
            doc.SendStringToExecute("AIDAPPLY ", true, false, false);
        }
    }
}
